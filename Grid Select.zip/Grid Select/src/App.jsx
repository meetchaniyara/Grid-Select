import './App.css';
import GridSelect from './pages/grid';

function App() {

  return (
    <>
      <GridSelect />
    </>
  );
}

export default App;
